# Cardápio de Bolos - Fabi Werneck

Site de cardápio editável para o Ateliê de Doces e Bolos da Fabi Werneck.

## Funcionalidades

✅ **Cardápio Organizado por Categorias**
- Tradicional (Bolo de Chocolate, Bolo de Cenoura)
- Premium (Bolo Red Velvet)
- Frutas (Bolo de Morango, Bolo de Limão)
- Personalizado (Bolo Personalizado)

✅ **Edição de Preços em Tempo Real**
- Clique em "Editar Preços" para ativar o modo de edição
- Altere preços, nomes e descrições dos bolos
- Clique em "Salvar" para confirmar as alterações
- As alterações são salvas no navegador (localStorage)

✅ **Integração com Redes Sociais**
- Botão do Instagram que leva ao perfil @fabiana.r.werneck
- Botões de encomenda via WhatsApp (+55 11 97506-2047)
- Mensagem automática no WhatsApp com detalhes do bolo

✅ **Design Responsivo**
- Funciona perfeitamente em desktop e mobile
- Interface moderna e atrativa
- Logo da Fabi Werneck integrada

## Como Usar

### Para Visualizar o Site:
1. Abra o terminal na pasta do projeto
2. Execute: `npm run dev -- --host`
3. Acesse: http://localhost:5173

### Para Editar Preços:
1. Clique no botão "Editar Preços" no canto superior direito
2. Altere os valores desejados nos campos que aparecem
3. Clique em "Salvar" para confirmar ou "Cancelar" para descartar

### Para Fazer Encomendas:
1. Clique no botão "Encomendar" do bolo desejado
2. Será aberto o WhatsApp com uma mensagem pré-formatada
3. Complete a conversa com a Fabi para finalizar o pedido

## Tecnologias Utilizadas

- React 18
- Tailwind CSS
- shadcn/ui Components
- Lucide Icons
- Vite (Build Tool)

## Estrutura do Projeto

```
cardapio-bolos/
├── src/
│   ├── assets/
│   │   └── logo.jpg (Logo da Fabi Werneck)
│   ├── components/ui/ (Componentes do shadcn/ui)
│   ├── App.jsx (Componente principal)
│   ├── App.css (Estilos)
│   └── main.jsx (Ponto de entrada)
├── public/
├── package.json
└── README.md
```

## Contatos

- **Instagram:** @fabiana.r.werneck
- **WhatsApp:** +55 11 97506-2047
- **Negócio:** Fabi Werneck - Ateliê de Doces e Bolos

---

*Site desenvolvido com React e design responsivo para proporcionar a melhor experiência aos clientes da Fabi Werneck.*

