import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Instagram, MessageCircle, Settings } from 'lucide-react'
import logo from './assets/logo.jpg'
import './App.css'

const API_BASE_URL = 'http://localhost:5000/api'

function App() {
  const [bolos, setBolos] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadBolos()
  }, [])

  const loadBolos = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/bolos`)
      if (!response.ok) {
        throw new Error('Erro ao carregar bolos')
      }
      const data = await response.json()
      setBolos(data)
    } catch (error) {
      console.error('Erro ao carregar bolos:', error)
      setError('Erro ao carregar o cardápio. Tente novamente mais tarde.')
    } finally {
      setLoading(false)
    }
  }

  const whatsappNumber = '+5511975062047'
  const instagramHandle = 'fabiana.r.werneck'

  const openWhatsApp = (bolo) => {
    const message = `Olá! Gostaria de encomendar o ${bolo.nome} - R$ ${bolo.preco}`
    const url = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`
    window.open(url, '_blank')
  }

  const openInstagram = () => {
    window.open(`https://instagram.com/${instagramHandle}`, '_blank')
  }

  const openAdmin = () => {
    window.open('http://localhost:3000', '_blank')
  }

  // Agrupar bolos por categoria
  const bolosPorCategoria = bolos.reduce((acc, bolo) => {
    if (!acc[bolo.categoria]) {
      acc[bolo.categoria] = []
    }
    acc[bolo.categoria].push(bolo)
    return acc
  }, {})

  const categorias = Object.keys(bolosPorCategoria)

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 text-lg">Carregando cardápio...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <p className="text-gray-600 text-lg">{error}</p>
          <Button 
            onClick={loadBolos} 
            className="mt-4 bg-pink-600 hover:bg-pink-700"
          >
            Tentar Novamente
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <img 
                src={logo} 
                alt="Fabi Werneck Logo" 
                className="w-16 h-16 rounded-full object-cover shadow-md"
              />
              <div>
                <h1 className="text-3xl font-bold text-gray-800">Fabi Werneck</h1>
                <p className="text-lg text-gray-600">Ateliê de Doces e Bolos</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button 
                onClick={openInstagram}
                variant="outline" 
                size="sm"
                className="flex items-center space-x-2 hover:bg-pink-50"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </Button>
              
              <Button 
                onClick={openAdmin}
                variant="outline" 
                size="sm"
                className="flex items-center space-x-2"
              >
                <Settings className="w-4 h-4" />
                <span>Painel Admin</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Nosso Cardápio</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Se está em busca de um bolo delicioso, de massa leve, saborosa, acompanhada de 
            recheios maravilhosos e uma decoração impecável... Acabou de encontrar!
          </p>
        </div>

        {/* Cardápio por Categoria */}
        {categorias.map(categoria => (
          <div key={categoria} className="mb-8">
            <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
              <Badge variant="secondary" className="mr-2 text-lg px-3 py-1">
                {categoria}
              </Badge>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bolosPorCategoria[categoria].map(bolo => (
                <Card key={bolo.id} className="hover:shadow-lg transition-shadow duration-300 overflow-hidden">
                  {bolo.imagem_url && (
                    <div className="aspect-video overflow-hidden">
                      <img 
                        src={`http://localhost:5000${bolo.imagem_url}`}
                        alt={bolo.nome}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="text-xl">{bolo.nome}</CardTitle>
                    <CardDescription>{bolo.descricao}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="text-2xl font-bold text-green-600">
                        R$ {bolo.preco}
                      </div>
                      <Button 
                        onClick={() => openWhatsApp(bolo)}
                        className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Encomendar</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}

        {bolos.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🍰</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Cardápio em Construção
            </h3>
            <p className="text-gray-600">
              Estamos preparando deliciosos bolos para você. Volte em breve!
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-6 mb-4">
              <Button 
                onClick={openInstagram}
                variant="ghost" 
                className="flex items-center space-x-2 text-pink-600 hover:text-pink-700"
              >
                <Instagram className="w-5 h-5" />
                <span>@{instagramHandle}</span>
              </Button>
              
              <Button 
                onClick={() => window.open(`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`, '_blank')}
                variant="ghost" 
                className="flex items-center space-x-2 text-green-600 hover:text-green-700"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{whatsappNumber}</span>
              </Button>
            </div>
            
            <p className="text-gray-600">
              © 2024 Fabi Werneck - Ateliê de Doces e Bolos. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

