from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from src.models.user import db
from src.models.bolo import Bolo, Categoria
import os
from werkzeug.utils import secure_filename
import uuid

bolo_bp = Blueprint('bolo', __name__)

# Configuração para upload de imagens
UPLOAD_FOLDER = 'src/static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_upload_folder():
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

# Rotas para Bolos
@bolo_bp.route('/bolos', methods=['GET'])
@cross_origin()
def get_bolos():
    try:
        bolos = Bolo.query.filter_by(ativo=True).all()
        return jsonify([bolo.to_dict() for bolo in bolos])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bolo_bp.route('/bolos/<int:bolo_id>', methods=['GET'])
@cross_origin()
def get_bolo(bolo_id):
    try:
        bolo = Bolo.query.get_or_404(bolo_id)
        return jsonify(bolo.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bolo_bp.route('/bolos', methods=['POST'])
@cross_origin()
def create_bolo():
    try:
        create_upload_folder()
        
        data = request.form
        nome = data.get('nome')
        descricao = data.get('descricao')
        preco = data.get('preco')
        categoria = data.get('categoria')
        
        if not all([nome, descricao, preco, categoria]):
            return jsonify({'error': 'Todos os campos são obrigatórios'}), 400
        
        imagem_url = None
        if 'imagem' in request.files:
            file = request.files['imagem']
            if file and file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Gerar nome único para evitar conflitos
                unique_filename = f"{uuid.uuid4()}_{filename}"
                file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
                file.save(file_path)
                imagem_url = f"/uploads/{unique_filename}"
        
        novo_bolo = Bolo(
            nome=nome,
            descricao=descricao,
            preco=preco,
            categoria=categoria,
            imagem_url=imagem_url
        )
        
        db.session.add(novo_bolo)
        db.session.commit()
        
        return jsonify(novo_bolo.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bolo_bp.route('/bolos/<int:bolo_id>', methods=['PUT'])
@cross_origin()
def update_bolo(bolo_id):
    try:
        bolo = Bolo.query.get_or_404(bolo_id)
        
        data = request.form
        if 'nome' in data:
            bolo.nome = data['nome']
        if 'descricao' in data:
            bolo.descricao = data['descricao']
        if 'preco' in data:
            bolo.preco = data['preco']
        if 'categoria' in data:
            bolo.categoria = data['categoria']
        
        # Atualizar imagem se fornecida
        if 'imagem' in request.files:
            file = request.files['imagem']
            if file and file.filename != '' and allowed_file(file.filename):
                create_upload_folder()
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
                file.save(file_path)
                bolo.imagem_url = f"/uploads/{unique_filename}"
        
        db.session.commit()
        return jsonify(bolo.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bolo_bp.route('/bolos/<int:bolo_id>', methods=['DELETE'])
@cross_origin()
def delete_bolo(bolo_id):
    try:
        bolo = Bolo.query.get_or_404(bolo_id)
        bolo.ativo = False  # Soft delete
        db.session.commit()
        return jsonify({'message': 'Bolo removido com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Rotas para Categorias
@bolo_bp.route('/categorias', methods=['GET'])
@cross_origin()
def get_categorias():
    try:
        categorias = Categoria.query.filter_by(ativo=True).all()
        return jsonify([categoria.to_dict() for categoria in categorias])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bolo_bp.route('/categorias', methods=['POST'])
@cross_origin()
def create_categoria():
    try:
        data = request.get_json()
        nome = data.get('nome')
        descricao = data.get('descricao', '')
        
        if not nome:
            return jsonify({'error': 'Nome da categoria é obrigatório'}), 400
        
        nova_categoria = Categoria(nome=nome, descricao=descricao)
        db.session.add(nova_categoria)
        db.session.commit()
        
        return jsonify(nova_categoria.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

