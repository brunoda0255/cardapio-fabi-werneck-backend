import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.bolo import bolo_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Habilitar CORS para todas as rotas
CORS(app)

app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(bolo_bp, url_prefix='/api')

# uncomment if you need to use database
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Importar modelos para criar as tabelas
from src.models.bolo import Bolo, Categoria

with app.app_context():
    db.create_all()
    
    # Criar categorias padrão se não existirem
    if Categoria.query.count() == 0:
        categorias_padrao = [
            Categoria(nome='Tradicional', descricao='Bolos tradicionais e clássicos'),
            Categoria(nome='Premium', descricao='Bolos especiais e sofisticados'),
            Categoria(nome='Frutas', descricao='Bolos com frutas frescas'),
            Categoria(nome='Personalizado', descricao='Bolos decorados sob medida')
        ]
        for categoria in categorias_padrao:
            db.session.add(categoria)
        db.session.commit()
    
    # Criar bolos padrão se não existirem
    if Bolo.query.count() == 0:
        bolos_padrao = [
            Bolo(nome='Bolo de Chocolate', descricao='Delicioso bolo de chocolate com cobertura cremosa', preco='45.00', categoria='Tradicional'),
            Bolo(nome='Bolo de Cenoura', descricao='Bolo de cenoura com cobertura de chocolate', preco='40.00', categoria='Tradicional'),
            Bolo(nome='Bolo Red Velvet', descricao='Bolo aveludado com cream cheese', preco='55.00', categoria='Premium'),
            Bolo(nome='Bolo de Morango', descricao='Bolo com morangos frescos e chantilly', preco='50.00', categoria='Frutas'),
            Bolo(nome='Bolo de Limão', descricao='Bolo cítrico com cobertura de limão', preco='42.00', categoria='Frutas'),
            Bolo(nome='Bolo Personalizado', descricao='Bolo decorado conforme sua preferência', preco='80.00', categoria='Personalizado')
        ]
        for bolo in bolos_padrao:
            db.session.add(bolo)
        db.session.commit()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
