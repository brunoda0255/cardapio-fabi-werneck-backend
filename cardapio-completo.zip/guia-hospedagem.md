# Guia de Hospedagem - Cardápio Dinâmico Fabi Werneck

## Resumo do Sistema Desenvolvido

Você agora possui um sistema completo de cardápio dinâmico que inclui:

### ✅ **Frontend do Cardápio** (React)
- Site público com o cardápio organizado por categorias
- Integração com Instagram e WhatsApp
- Design responsivo (funciona em celular e desktop)
- Carrega dados dinamicamente da API

### ✅ **Painel de Administração** (React)
- Interface para gerenciar o cardápio
- Adicionar/editar/remover bolos
- Upload de imagens
- Estatísticas em tempo real

### ✅ **Backend/API** (Flask + SQLite)
- API REST completa para gerenciar bolos
- Sistema de upload de imagens
- Banco de dados SQLite integrado
- CORS habilitado para integração frontend-backend

## Opções de Hospedagem Recomendadas

Com base na pesquisa realizada, aqui estão as **melhores opções** para hospedar seu sistema completo:

### 🥇 **Render (Recomendado)**
**Por que é a melhor opção:**
- ✅ Hospedagem gratuita para aplicações Flask
- ✅ Suporte nativo ao SQLite
- ✅ Deploy automático via GitHub
- ✅ HTTPS gratuito
- ✅ Fácil de configurar

**Como usar:**
1. Crie uma conta em [render.com](https://render.com)
2. Conecte seu repositório GitHub
3. Configure como "Web Service"
4. Render detecta automaticamente que é Flask

### 🥈 **Railway (Alternativa Excelente)**
**Vantagens:**
- ✅ Interface muito simples
- ✅ Deploy com um clique
- ✅ Plano gratuito generoso
- ✅ Suporte completo ao Flask + SQLite

### 🥉 **Fly.io (Para Usuários Avançados)**
**Vantagens:**
- ✅ Performance excelente
- ✅ Configuração flexível
- ✅ Plano gratuito disponível

## Arquivos Necessários para Deploy

Para fazer o deploy, você precisará dos seguintes arquivos (já criados):

### 📁 **Backend (Flask)**
```
cardapio-backend/
├── src/
│   ├── main.py (aplicação principal)
│   ├── models/ (modelos do banco)
│   ├── routes/ (rotas da API)
│   └── static/ (arquivos estáticos)
├── requirements.txt (dependências)
└── README.md
```

### 📁 **Frontend do Cardápio**
```
cardapio-bolos/
├── src/
├── package.json
└── dist/ (após build)
```

### 📁 **Painel de Administração**
```
admin-panel/
├── src/
├── package.json
└── dist/ (após build)
```

## Passo a Passo Detalhado - Render

### **Etapa 1: Preparar o Backend para Deploy**

1. **Atualizar requirements.txt:**
```bash
cd cardapio-backend
source venv/bin/activate
pip freeze > requirements.txt
```

2. **Criar arquivo de configuração do Render:**
Crie um arquivo `render.yaml` na raiz do projeto:
```yaml
services:
  - type: web
    name: cardapio-backend
    env: python
    buildCommand: "pip install -r requirements.txt"
    startCommand: "python src/main.py"
    envVars:
      - key: PYTHON_VERSION
        value: 3.11.0
```

### **Etapa 2: Fazer Deploy no Render**

1. **Criar conta no Render:**
   - Acesse [render.com](https://render.com)
   - Crie conta gratuita (pode usar GitHub)

2. **Conectar repositório:**
   - Clique em "New +" → "Web Service"
   - Conecte seu repositório GitHub
   - Selecione a pasta `cardapio-backend`

3. **Configurar o serviço:**
   - **Name:** `cardapio-fabi-werneck`
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python src/main.py`

4. **Deploy automático:**
   - Render fará o deploy automaticamente
   - Você receberá uma URL como: `https://cardapio-fabi-werneck.onrender.com`

### **Etapa 3: Configurar Frontend para Produção**

1. **Atualizar URLs da API:**
No arquivo `cardapio-bolos/src/App.jsx`, altere:
```javascript
// De:
const API_BASE_URL = 'http://localhost:5000/api'

// Para:
const API_BASE_URL = 'https://cardapio-fabi-werneck.onrender.com/api'
```

2. **Fazer build do frontend:**
```bash
cd cardapio-bolos
npm run build
```

3. **Copiar arquivos para o backend:**
```bash
cp -r dist/* ../cardapio-backend/src/static/
```

### **Etapa 4: Configurar Painel de Administração**

1. **Atualizar URLs da API no painel:**
No arquivo `admin-panel/src/App.jsx`, altere:
```javascript
// De:
const API_BASE_URL = 'http://localhost:5000/api'

// Para:
const API_BASE_URL = 'https://cardapio-fabi-werneck.onrender.com/api'
```

2. **Fazer build do painel:**
```bash
cd admin-panel
npm run build
```

3. **Hospedar o painel separadamente:**
   - Use Netlify ou Vercel para o painel de administração
   - Faça upload da pasta `dist` gerada

## Links Finais

Após o deploy completo, você terá:

### 🌐 **Site do Cardápio (Público)**
`https://cardapio-fabi-werneck.onrender.com`
- Este é o link que você compartilha com clientes
- Mostra o cardápio atualizado em tempo real

### ⚙️ **Painel de Administração**
`https://admin-fabi-werneck.netlify.app` (exemplo)
- Use este link para gerenciar o cardápio
- Adicionar/editar bolos e preços
- Fazer upload de fotos

## Custos

### **Render (Backend):**
- ✅ **Gratuito** até 750 horas/mês
- ✅ Mais que suficiente para um cardápio

### **Netlify (Painel Admin):**
- ✅ **Gratuito** para sites estáticos
- ✅ Sem limites para seu uso

### **Total: R$ 0,00/mês** 🎉

## Suporte Técnico

Se precisar de ajuda durante o processo:
1. Siga este guia passo a passo
2. Verifique se todos os arquivos estão no lugar correto
3. Teste localmente antes do deploy
4. Entre em contato se houver dificuldades

## Próximos Passos

1. **Faça backup** de todos os arquivos
2. **Teste o sistema** localmente uma última vez
3. **Siga o guia** de deploy passo a passo
4. **Compartilhe o link** com sua mãe quando estiver pronto

Seu sistema está pronto para ser usado profissionalmente! 🚀

