import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Plus, Edit2, Trash2, Upload, Eye, ExternalLink } from 'lucide-react'
import logo from './assets/logo.jpg'
import './App.css'

const API_BASE_URL = 'http://localhost:5000/api'

function App() {
  const [bolos, setBolos] = useState([])
  const [categorias, setCategorias] = useState([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingBolo, setEditingBolo] = useState(null)
  const [formData, setFormData] = useState({
    nome: '',
    descricao: '',
    preco: '',
    categoria: '',
    imagem: null
  })

  // Carregar dados iniciais
  useEffect(() => {
    loadBolos()
    loadCategorias()
  }, [])

  const loadBolos = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/bolos`)
      const data = await response.json()
      setBolos(data)
    } catch (error) {
      console.error('Erro ao carregar bolos:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadCategorias = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/categorias`)
      const data = await response.json()
      setCategorias(data)
    } catch (error) {
      console.error('Erro ao carregar categorias:', error)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    const formDataToSend = new FormData()
    formDataToSend.append('nome', formData.nome)
    formDataToSend.append('descricao', formData.descricao)
    formDataToSend.append('preco', formData.preco)
    formDataToSend.append('categoria', formData.categoria)
    
    if (formData.imagem) {
      formDataToSend.append('imagem', formData.imagem)
    }

    try {
      const url = editingBolo 
        ? `${API_BASE_URL}/bolos/${editingBolo.id}`
        : `${API_BASE_URL}/bolos`
      
      const method = editingBolo ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        body: formDataToSend
      })

      if (response.ok) {
        await loadBolos()
        resetForm()
        setDialogOpen(false)
      } else {
        console.error('Erro ao salvar bolo')
      }
    } catch (error) {
      console.error('Erro ao salvar bolo:', error)
    }
  }

  const handleEdit = (bolo) => {
    setEditingBolo(bolo)
    setFormData({
      nome: bolo.nome,
      descricao: bolo.descricao,
      preco: bolo.preco,
      categoria: bolo.categoria,
      imagem: null
    })
    setDialogOpen(true)
  }

  const handleDelete = async (id) => {
    if (confirm('Tem certeza que deseja remover este bolo?')) {
      try {
        const response = await fetch(`${API_BASE_URL}/bolos/${id}`, {
          method: 'DELETE'
        })
        
        if (response.ok) {
          await loadBolos()
        }
      } catch (error) {
        console.error('Erro ao remover bolo:', error)
      }
    }
  }

  const resetForm = () => {
    setFormData({
      nome: '',
      descricao: '',
      preco: '',
      categoria: '',
      imagem: null
    })
    setEditingBolo(null)
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    setFormData({ ...formData, imagem: file })
  }

  const openCardapio = () => {
    window.open('http://localhost:5173', '_blank')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <img 
                src={logo} 
                alt="Fabi Werneck Logo" 
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Painel Administrativo</h1>
                <p className="text-sm text-gray-500">Fabi Werneck - Ateliê de Doces e Bolos</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button 
                onClick={openCardapio}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Ver Cardápio</span>
              </Button>
              
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={resetForm}
                    className="flex items-center space-x-2 bg-pink-600 hover:bg-pink-700"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Adicionar Bolo</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>
                      {editingBolo ? 'Editar Bolo' : 'Adicionar Novo Bolo'}
                    </DialogTitle>
                    <DialogDescription>
                      {editingBolo 
                        ? 'Edite as informações do bolo abaixo.'
                        : 'Preencha as informações do novo bolo abaixo.'
                      }
                    </DialogDescription>
                  </DialogHeader>
                  
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="nome">Nome do Bolo</Label>
                      <Input
                        id="nome"
                        value={formData.nome}
                        onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                        placeholder="Ex: Bolo de Chocolate"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="descricao">Descrição</Label>
                      <Textarea
                        id="descricao"
                        value={formData.descricao}
                        onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                        placeholder="Descreva o bolo..."
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="preco">Preço (R$)</Label>
                        <Input
                          id="preco"
                          value={formData.preco}
                          onChange={(e) => setFormData({ ...formData, preco: e.target.value })}
                          placeholder="45.00"
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="categoria">Categoria</Label>
                        <Select 
                          value={formData.categoria} 
                          onValueChange={(value) => setFormData({ ...formData, categoria: value })}
                          required
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione..." />
                          </SelectTrigger>
                          <SelectContent>
                            {categorias.map((categoria) => (
                              <SelectItem key={categoria.id} value={categoria.nome}>
                                {categoria.nome}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="imagem">Imagem do Bolo</Label>
                      <div className="flex items-center space-x-2">
                        <Input
                          id="imagem"
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="flex-1"
                        />
                        <Upload className="w-4 h-4 text-gray-400" />
                      </div>
                      <p className="text-xs text-gray-500">
                        Formatos aceitos: PNG, JPG, JPEG, GIF, WebP
                      </p>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setDialogOpen(false)}
                      >
                        Cancelar
                      </Button>
                      <Button type="submit" className="bg-pink-600 hover:bg-pink-700">
                        {editingBolo ? 'Atualizar' : 'Adicionar'}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Gerenciar Cardápio</h2>
          <p className="text-gray-600">
            Adicione, edite ou remova bolos do seu cardápio. As alterações aparecerão imediatamente no site.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Bolos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{bolos.length}</div>
              <p className="text-xs text-muted-foreground">bolos no cardápio</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Categorias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{categorias.length}</div>
              <p className="text-xs text-muted-foreground">categorias ativas</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Com Imagens</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {bolos.filter(bolo => bolo.imagem_url).length}
              </div>
              <p className="text-xs text-muted-foreground">bolos com fotos</p>
            </CardContent>
          </Card>
        </div>

        {/* Bolos Table */}
        <Card>
          <CardHeader>
            <CardTitle>Lista de Bolos</CardTitle>
            <CardDescription>
              Gerencie todos os bolos do seu cardápio
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Imagem</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Preço</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bolos.map((bolo) => (
                    <TableRow key={bolo.id}>
                      <TableCell>
                        {bolo.imagem_url ? (
                          <img 
                            src={`http://localhost:5000${bolo.imagem_url}`} 
                            alt={bolo.nome}
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-gray-200 flex items-center justify-center">
                            <Upload className="w-4 h-4 text-gray-400" />
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="font-medium">{bolo.nome}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{bolo.categoria}</Badge>
                      </TableCell>
                      <TableCell className="font-semibold text-green-600">
                        R$ {bolo.preco}
                      </TableCell>
                      <TableCell className="max-w-xs truncate">
                        {bolo.descricao}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(bolo)}
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(bolo.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

export default App

